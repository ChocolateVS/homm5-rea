@echo off
rem H5Reborn beta - jump straight into a duel against the computer.
rem Usage: "Duel vs Computer.bat" [yourPreset] [enemyPreset]   (duel presets 0-23)
set A=%1
set B=%2
if "%A%"=="" set A=0
if "%B%"=="" set B=3
cd /d "%~dp0"
start "" "%~dp0H5Reborn.exe" -- --combat-vs-ai=%A%,%B%
