@echo off
rem H5Reborn beta - main menu. Needs your own Heroes V: Tribes of the East install (MMH 5.5 or plain 3.1).
rem If the game is not found automatically, put its folder in game_dir.txt or set H5_GAME_DIR.
cd /d "%~dp0"
start "" "%~dp0H5Reborn.exe" %*
