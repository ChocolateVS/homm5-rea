@echo off
rem Dedicated multiplayer server (default port 27615, TCP+UDP). Players use
rem Multi Player > Local Network and join this PC's IP. Extra options: --name NAME --port N
cd /d "%~dp0"
"%~dp0data_H5Reborn_windows_x86_64\h5server.exe" --port 27615 %*
pause
