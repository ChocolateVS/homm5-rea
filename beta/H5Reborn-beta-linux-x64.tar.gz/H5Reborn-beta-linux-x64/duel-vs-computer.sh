#!/bin/sh
# H5Reborn beta - jump straight into a duel against the computer.
# Usage: ./duel-vs-computer.sh [yourPreset] [enemyPreset]   (duel presets 0-23)
cd "$(dirname "$0")" || exit 1
exec ./H5Reborn.x86_64 -- --combat-vs-ai="${1:-0},${2:-3}"
