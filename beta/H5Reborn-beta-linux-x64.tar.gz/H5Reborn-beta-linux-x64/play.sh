#!/bin/sh
# H5Reborn beta - main menu. Needs your own Heroes V: Tribes of the East install (MMH 5.5 or plain 3.1).
# If the game is not found automatically, put its folder in game_dir.txt or set H5_GAME_DIR.
cd "$(dirname "$0")" || exit 1
exec ./H5Reborn.x86_64 "$@"
