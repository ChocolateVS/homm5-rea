#!/bin/sh
# Dedicated multiplayer server (default port 27615, TCP+UDP). Players use
# Multi Player > Local Network and join this machine's IP. Extra options: --name NAME --port N
cd "$(dirname "$0")" || exit 1
exec ./data_H5Reborn_linuxbsd_x86_64/h5server --port 27615 "$@"
